// Arquivo: src/app/cadastro-despesa.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OrcamentoService } from './orcamento.service'; // Corrigido para o caminho certo

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './cadastro-despesa.component.html', // Vamos criar este arquivo
  styleUrls: ['./cadastro-despesa.component.css'], // E este também
})
export class CadastroDespesaComponent {
  descricao: string = '';
  valor: number | null = null;
  categoria: string = '';

  // Categorias sugeridas para despesas
  categorias: string[] = [
    'Alimentação',
    'Transporte',
    'Moradia',
    'Lazer',
    'Outros',
  ];

  constructor(private orcamentoService: OrcamentoService) {}

  salvarDespesa() {
    if (this.descricao && this.valor && this.valor > 0 && this.categoria) {
      this.orcamentoService.adicionarDespesa({
        descricao: this.descricao,
        valor: this.valor,
        categoria: this.categoria,
      });

      // Limpa o formulário
      this.descricao = '';
      this.valor = null;
      this.categoria = '';
      alert('Despesa salva com sucesso!');
    } else {
      alert('Por favor, preencha todos os campos corretamente.');
    }
  }
}
