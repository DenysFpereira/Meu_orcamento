import { Component } from '@angular/core';
// 1. IMPORTE O RouterLink AQUI
import { RouterOutlet, RouterLink } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  // 2. ADICIONE O RouterLink AQUI na lista
  imports: [RouterOutlet, RouterLink],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'meu-orcamento';
}
