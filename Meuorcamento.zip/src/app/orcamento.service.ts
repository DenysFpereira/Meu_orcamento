import { Injectable } from '@angular/core';

export interface Receita {
  id: number; // ID adicionado
  descricao: string;
  valor: number;
  categoria: string;
}

export interface Despesa {
  id: number; // ID adicionado
  descricao: string;
  valor: number;
  categoria: string;
}

@Injectable({
  providedIn: 'root',
})
export class OrcamentoService {
  private receitas: Receita[] = [];
  private despesas: Despesa[] = [];

  constructor() {}

  adicionarReceita(receita: Omit<Receita, 'id'>) {
    this.receitas.push({ ...receita, id: Date.now() }); // Adiciona ID ao salvar
  }

  adicionarDespesa(despesa: Omit<Despesa, 'id'>) {
    this.despesas.push({ ...despesa, id: Date.now() }); // Adiciona ID ao salvar
  }

  // ... (outros métodos get e de cálculo continuam iguais)
  getReceitas(): Receita[] {
    return this.receitas;
  }
  getDespesas(): Despesa[] {
    return this.despesas;
  }
  calcularTotalReceitas(): number {
    return this.receitas.reduce((total, r) => total + r.valor, 0);
  }
  calcularTotalDespesas(): number {
    return this.despesas.reduce((total, d) => total + d.valor, 0);
  }
  calcularSaldoFinal(): number {
    return this.calcularTotalReceitas() - this.calcularTotalDespesas();
  }
  calcularMediaDespesas(): number {
    if (this.despesas.length === 0) return 0;
    return this.calcularTotalDespesas() / this.despesas.length;
  }
  calcularPercentualDespesasPorCategoria() {
    const totalDespesas = this.calcularTotalDespesas();
    if (totalDespesas === 0) return [];
    const gastosPorCategoria = new Map<string, number>();
    for (const despesa of this.despesas) {
      const gastoAtual = gastosPorCategoria.get(despesa.categoria) || 0;
      gastosPorCategoria.set(despesa.categoria, gastoAtual + despesa.valor);
    }
    const resultado = Array.from(gastosPorCategoria.entries()).map(
      ([categoria, valor]) => ({
        categoria,
        valor,
        percentual: (valor / totalDespesas) * 100,
      })
    );
    return resultado;
  }

  // --- NOVOS MÉTODOS DE EXCLUSÃO ---
  excluirReceita(id: number) {
    this.receitas = this.receitas.filter((r) => r.id !== id);
  }

  excluirDespesa(id: number) {
    this.despesas = this.despesas.filter((d) => d.id !== id);
  }
}
