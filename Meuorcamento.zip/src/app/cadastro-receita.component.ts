// Arquivo: src/app/cadastro-receita.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // Importante para formulários
import { OrcamentoService } from './orcamento.service';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule], // Adiciona CommonModule e FormsModule
  templateUrl: './cadastro-receita.component.html', // Vamos criar este arquivo
  styleUrls: ['./cadastro-receita.component.css'], // E este também
})
export class CadastroReceitaComponent {
  // Variáveis para guardar os dados do formulário
  descricao: string = '';
  valor: number | null = null;
  categoria: string = '';

  // Lista de categorias sugeridas
  categorias: string[] = ['Salário', 'Freelance', 'Investimentos', 'Outros'];

  // Injeta nosso serviço para poder usá-lo
  constructor(private orcamentoService: OrcamentoService) {}

  salvarReceita() {
    // Validação dos campos [cite: 36]
    if (this.descricao && this.valor && this.valor > 0 && this.categoria) {
      this.orcamentoService.adicionarReceita({
        descricao: this.descricao,
        valor: this.valor,
        categoria: this.categoria,
      });

      // Limpa o formulário após salvar
      this.descricao = '';
      this.valor = null;
      this.categoria = '';
      alert('Receita salva com sucesso!');
    } else {
      alert('Por favor, preencha todos os campos corretamente.');
    }
  }
}
