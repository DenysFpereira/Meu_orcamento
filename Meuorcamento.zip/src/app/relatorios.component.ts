import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrcamentoService } from './orcamento.service';

interface DespesaPorCategoria {
  categoria: string;
  valor: number;
  percentual: number;
}

@Component({
  standalone: true,
  imports: [CommonModule],
  templateUrl: './relatorios.component.html',
  styleUrls: ['./relatorios.component.css'],
})
export class RelatoriosComponent implements OnInit {
  saldoFinal: number = 0;
  mediaDespesas: number = 0;
  despesasPorCategoria: DespesaPorCategoria[] = [];

  constructor(private orcamentoService: OrcamentoService) {}

  ngOnInit(): void {
    this.saldoFinal = this.orcamentoService.calcularSaldoFinal();
    this.mediaDespesas = this.orcamentoService.calcularMediaDespesas();
    this.despesasPorCategoria =
      this.orcamentoService.calcularPercentualDespesasPorCategoria();
  }
}
