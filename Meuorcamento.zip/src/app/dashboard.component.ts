import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrcamentoService } from './orcamento.service';

@Component({
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  totalReceitas: number = 0;
  totalDespesas: number = 0;
  saldoFinal: number = 0;

  constructor(private orcamentoService: OrcamentoService) {}

  ngOnInit(): void {
    this.totalReceitas = this.orcamentoService.calcularTotalReceitas();
    this.totalDespesas = this.orcamentoService.calcularTotalDespesas();
    this.saldoFinal = this.orcamentoService.calcularSaldoFinal();
  }
}
