import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OrcamentoService, Receita, Despesa } from './orcamento.service'; // Caminho corrigido

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './lista-lancamentos.component.html',
  styleUrls: ['./lista-lancamentos.component.css'],
})
export class ListaLancamentosComponent implements OnInit {
  todasReceitas: Receita[] = [];
  todasDespesas: Despesa[] = [];
  receitasFiltradas: Receita[] = [];
  despesasFiltradas: Despesa[] = [];
  termoBusca: string = '';

  constructor(private orcamentoService: OrcamentoService) {}

  ngOnInit() {
    this.atualizarListas();
  }

  atualizarListas() {
    this.todasReceitas = this.orcamentoService.getReceitas();
    this.todasDespesas = this.orcamentoService.getDespesas();
    this.filtrarLancamentos();
  }

  filtrarLancamentos() {
    const termo = this.termoBusca.toLowerCase();
    this.receitasFiltradas = this.todasReceitas.filter((r) =>
      r.descricao.toLowerCase().includes(termo)
    );
    this.despesasFiltradas = this.todasDespesas.filter((d) =>
      d.descricao.toLowerCase().includes(termo)
    );
  }

  // --- NOVOS MÉTODOS DE EXCLUSÃO ---
  excluirReceita(id: number) {
    if (confirm('Tem certeza que deseja excluir esta receita?')) {
      this.orcamentoService.excluirReceita(id);
      this.atualizarListas(); // Atualiza a lista na tela
    }
  }

  excluirDespesa(id: number) {
    if (confirm('Tem certeza que deseja excluir esta despesa?')) {
      this.orcamentoService.excluirDespesa(id);
      this.atualizarListas(); // Atualiza a lista na tela
    }
  }
}
