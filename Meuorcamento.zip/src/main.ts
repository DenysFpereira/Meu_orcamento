import 'zone.js';
import { bootstrapApplication } from '@angular/platform-browser';
import {
  provideRouter,
  Routes,
  withHashLocation,
  withDebugTracing,
} from '@angular/router';
import { AppComponent } from './app/app.component';

// Importando todos os nossos novos componentes
import { DashboardComponent } from './app/dashboard.component';
import { CadastroReceitaComponent } from './app/cadastro-receita.component';
import { CadastroDespesaComponent } from './app/cadastro-despesa.component';
import { ListaLancamentosComponent } from './app/lista-lancamentos.component';
import { RelatoriosComponent } from './app/relatorios.component';

// Definindo o "mapa" de rotas da aplicação
const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'cadastrar-receita', component: CadastroReceitaComponent },
  { path: 'cadastrar-despesa', component: CadastroDespesaComponent },
  { path: 'lancamentos', component: ListaLancamentosComponent },
  { path: 'relatorios', component: RelatoriosComponent },
];

bootstrapApplication(AppComponent, {
  providers: [provideRouter(routes, withHashLocation(), withDebugTracing())],
}).catch((err: any) => console.error(err)); // Correção menor aqui
